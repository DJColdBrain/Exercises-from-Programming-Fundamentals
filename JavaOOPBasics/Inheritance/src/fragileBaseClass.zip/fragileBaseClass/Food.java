package fragileBaseClass;

public class Food {
}
