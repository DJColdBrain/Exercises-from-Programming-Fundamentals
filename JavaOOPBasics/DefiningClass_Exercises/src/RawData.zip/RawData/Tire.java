package RawData;

public class Tire {

    private int age;
    private double presure;

    public Tire(int age, double presure) {
        this.age = age;
        this.presure = presure;
    }

    public int getAge() {
        return age;
    }

    public double getPresure() {
        return presure;
    }
}
