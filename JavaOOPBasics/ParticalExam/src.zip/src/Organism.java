package cells;

import java.util.ArrayList;
import java.util.List;

public class Organism {
    private String name;
    private List<cells.Cluster> clusters;

    public Organism(String name) {
        setName(name);
        this.clusters = new ArrayList<>();
    }

    private void setName(String name){
        this.name = name;
    }

    @Override
    public String toString() {
        return "";
    }
}
