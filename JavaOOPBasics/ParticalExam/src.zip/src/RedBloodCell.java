package cells.bloodCells;

public class RedBloodCell extends cells.bloodCells.BloodCell {
    private int velocity;


    public RedBloodCell(String id, int health, int positionRow, int positionCol, int velocity) {
        super(id, health, positionRow, positionCol);
        setVelocity(velocity);
    }

    private void setVelocity(int velocity) {
        if (velocity <= 0){
            throw new IllegalArgumentException("");
        }
        this.velocity = velocity;
    }


    @Override
    public String toString() {
        return "";
    }
}
