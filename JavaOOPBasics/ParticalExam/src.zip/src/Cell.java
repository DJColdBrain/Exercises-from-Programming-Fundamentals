package cells;

public class Cell {
    private String id;
    private int health;
    private int positionRow;
    private int positionCol;

    public Cell(String id, int health, int positionRow, int positionCol) {
        this.id = id;
        this.health = health;
        this.positionRow = positionRow;
        this.positionCol = positionCol;
    }

    private void setId(String id) {
        this.id = id;
    }

    private void setHealth(int health) {
        if (health <= 0){
            throw new IllegalArgumentException("");
        }
        this.health = health;
    }

    private void setPositionRow(int positionRow) {
        if (positionRow <= 0){
            throw new IllegalArgumentException("");
        }
        this.positionRow = positionRow;
    }

    private void setPositionCol(int positionCol) {
        if (positionCol <= 0){
            throw new IllegalArgumentException("");
        }
        this.positionCol = positionCol;
    }



    @Override
    public String toString() {
        return "";
    }
}
