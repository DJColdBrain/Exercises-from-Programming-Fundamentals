package cells;

import cells.Organism;

import java.util.LinkedHashMap;

public class Storage {

    public static LinkedHashMap<String, Organism> organisms = new LinkedHashMap<>();
}
