package cells;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Cluster {
    private String id;
    private int rows;
    private int cols;
    private List<Cell> cells;


    public Cluster(String id, int rows, int cols){
        setId(id);
        setRows(rows);
        setCols(cols);
        this.cells = new ArrayList<>();
    }

    private void setId(String id) {
        this.id = id;
    }

    private void setRows(int rows) {
        if (rows <= 0){
            throw new IllegalArgumentException("");
        }
        this.rows = rows;
    }

    private void setCols(int cols) {
        if (cols <= 0){
            throw new IllegalArgumentException("");
        }
        this.cols = cols;
    }

    public void addCell(Cell cell){
        int n = 0;
        boolean b1 = false;
        boolean b2 = false;
        for (Cell cell1 : cells) {
            if (cell1.getPositionRow() >= cell.getPositionRow()){
                b1 = true;
            }
            if (cell1.getPositionCol() >= cell.getPositionCol()){
                b2 = true;
            }
            if (b1 && b2){
                cells.add(n,  cell);
                break;
            }else{
                n++;
            }
        }
        if (b1 && b2){
            return;
        }else{
            cells.add(cell);
        }
    }

    public String getId() {
        return id;
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    public List<Cell> getCells() {
        return this.cells;
    }



    @Override
    public String toString() {

        String toReturn = "\n----Cluster "+ getId() +"\n";
        for (Cell cell : cells) {
            toReturn+=cell;
        }

        return toReturn;
    }

}
