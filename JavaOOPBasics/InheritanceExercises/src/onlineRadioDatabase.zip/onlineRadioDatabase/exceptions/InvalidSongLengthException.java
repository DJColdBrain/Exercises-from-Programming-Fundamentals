package onlineRadioDatabase.exceptions;

public class InvalidSongLengthException extends InvalidSongException {

    public InvalidSongLengthException() {
        super(ExceptionConstants.INVALID_SONG_LENGHT);
    }

    public InvalidSongLengthException(String message) {
        super(message);
    }
}
