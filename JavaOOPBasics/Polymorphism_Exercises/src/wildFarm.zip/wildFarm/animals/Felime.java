package wildFarm.animals;

public abstract class Felime extends Mammal {
}
