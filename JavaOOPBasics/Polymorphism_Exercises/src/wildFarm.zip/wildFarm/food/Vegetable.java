package wildFarm.food;

public class Vegetable extends Food {

    public Vegetable(int quantity) {
        setQuantity(quantity);
    }
}
