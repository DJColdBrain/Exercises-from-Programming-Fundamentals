package avatar.benders;

public class Benders {
    private String name;
    private int power;

    protected String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    protected int getPower() {
        return power;
    }

    protected void setPower(int power) {
        this.power = power;
    }
}
