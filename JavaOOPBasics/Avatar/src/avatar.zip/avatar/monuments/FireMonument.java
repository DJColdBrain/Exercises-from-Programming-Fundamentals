package avatar.monuments;

public class FireMonument extends Monuments {
    private int FireAffinity;


    @Override
    public String toString() {
        return super.toString();
    }

    private int getFireAffinity() {
        return FireAffinity;
    }

    private void setFireAffinity(int fireAffinity) {
        FireAffinity = fireAffinity;
    }
}
