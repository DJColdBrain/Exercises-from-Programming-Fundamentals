package avatar.monuments;

public class EarthMonument extends Monuments {
    private int EarthAffinity;

    @Override
    public String toString() {
        return super.toString();
    }

    private int getEarthAffinity() {
        return EarthAffinity;
    }

    private void setEarthAffinity(int earthAffinity) {
        EarthAffinity = earthAffinity;
    }
}
