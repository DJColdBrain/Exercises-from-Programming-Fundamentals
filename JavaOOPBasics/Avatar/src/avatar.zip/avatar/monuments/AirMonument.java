package avatar.monuments;

public class AirMonument extends Monuments {
    private int AirAffinity;


    @Override
    public String toString() {
        return super.toString();
    }

    private int getAirAffinity() {
        return AirAffinity;
    }

    private void setAirAffinity(int airAffinity) {
        AirAffinity = airAffinity;
    }
}
