package avatar.monuments;

public class Monuments {
    private String name;


    @Override
    public String toString() {
        return super.toString();
    }

    protected String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }
}
