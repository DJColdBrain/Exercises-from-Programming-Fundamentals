package avatar;

public class Main {
}
