package com.statics;

public class SessionData {
    public static String currentPath = System.getProperty("user.dir");
}
