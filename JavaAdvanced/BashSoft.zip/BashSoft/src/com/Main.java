package com;


import com.IO.IOManager;
import com.IO.InputReader;
import com.commandInterpreter.CommandInterpreter;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        InputReader.readCommands();
    }
}
