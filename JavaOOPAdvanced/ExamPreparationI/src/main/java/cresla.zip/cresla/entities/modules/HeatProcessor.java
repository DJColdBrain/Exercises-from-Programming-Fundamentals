package cresla.entities.modules;


public class HeatProcessor extends AbstractAbsorbModule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
