package cresla.entities.modules;

public class CooldownSystem extends AbstractAbsorbModule {


    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
