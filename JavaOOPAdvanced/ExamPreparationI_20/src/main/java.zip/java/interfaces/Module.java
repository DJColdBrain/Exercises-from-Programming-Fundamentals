package interfaces;

public interface Module extends Identifiable {
}
