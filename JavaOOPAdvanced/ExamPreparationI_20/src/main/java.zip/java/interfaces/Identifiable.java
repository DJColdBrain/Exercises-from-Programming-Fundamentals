package interfaces;

public interface Identifiable {
    int getId();
}
