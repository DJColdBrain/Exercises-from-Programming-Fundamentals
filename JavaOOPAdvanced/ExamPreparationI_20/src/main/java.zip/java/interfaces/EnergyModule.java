package interfaces;

public interface EnergyModule extends Module {
    int getEnergyOutput();
}
