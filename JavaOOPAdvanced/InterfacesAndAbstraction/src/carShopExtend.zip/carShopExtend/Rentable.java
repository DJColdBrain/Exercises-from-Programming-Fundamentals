package carShopExtend;

public interface Rentable extends Car {

    Integer getMinRentDat();
    Double getPricePerDay();
}
