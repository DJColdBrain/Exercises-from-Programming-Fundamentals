package genericScale;

public class Main {
}
