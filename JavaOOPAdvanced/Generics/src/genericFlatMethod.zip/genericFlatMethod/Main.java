package genericFlatMethod;


public class Main {

}
