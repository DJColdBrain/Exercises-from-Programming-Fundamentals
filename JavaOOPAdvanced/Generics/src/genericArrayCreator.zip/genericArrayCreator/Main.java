package genericArrayCreator;

public class Main {
}
