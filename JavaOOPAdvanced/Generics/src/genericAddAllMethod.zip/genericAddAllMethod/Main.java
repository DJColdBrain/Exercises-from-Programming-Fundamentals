package genericAddAllMethod;


public class Main {

}
