package logger.commands;

import logger.interfaces.Attacker;
import logger.interfaces.Command;

public class AttackComand implements Command{

    private Attacker attacker;

    public AttackComand(Attacker attacker) {
        this.attacker = attacker;
    }

    @Override
    public void execute() {
        attacker.attack();
    }
}
