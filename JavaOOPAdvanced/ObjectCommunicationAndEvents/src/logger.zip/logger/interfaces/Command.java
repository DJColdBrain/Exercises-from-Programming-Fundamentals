package logger.interfaces;

public interface Command {

    void execute();
}
