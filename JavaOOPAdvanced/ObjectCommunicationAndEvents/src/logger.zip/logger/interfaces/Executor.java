package logger.interfaces;

public interface Executor {

    void executeCommand(Command command);

}
