package logger.interfaces;

public interface Observer {

    void update(int n);
}
