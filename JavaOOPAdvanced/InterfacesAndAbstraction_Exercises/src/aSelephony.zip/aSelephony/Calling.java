package Тelephony;

public interface Calling {

    String call(String number);
}
