package Тelephony;

public interface Browsing {

    String browse(String url);
}
