package BirthdayCelebrations;

public interface Birthable {

    String getBirthdate();
    boolean isBirthdayYear(String year);
}
