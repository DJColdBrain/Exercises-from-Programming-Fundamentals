package BorderControl;

public interface Identifiable {

    boolean isFakeId(String lastBit);
    String getId();
}
