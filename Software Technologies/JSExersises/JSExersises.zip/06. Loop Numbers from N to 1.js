/**
 * Created by DJColdBrain on 25-Jul-17.
 */

function a(s) {
    let num = Number(s[0]);
    for (let i = num; i >= 1 ; i--){
        console.log(i);
    }
}