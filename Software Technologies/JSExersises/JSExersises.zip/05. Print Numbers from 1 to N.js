/**
 * Created by DJColdBrain on 25-Jul-17.
 */

function a(s) {
    let num = Number(s[0]);
    for (let i = 1; i <= num ; i++){
        console.log(i);
    }
}