/**
 * Created by DJColdBrain on 25-Jul-17.
 */

function a(nums) {
    let num1 = nums[0];
    let num2 = nums[1];

    if (num1 <= num2){
        console.log(num1*num2);
    }else {
        console.log(num1/num2);
    }

}