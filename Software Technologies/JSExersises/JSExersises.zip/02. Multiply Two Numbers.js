/**
 * Created by DJColdBrain on 25-Jul-17.
 */

function a(nums ) {
    let sum = nums[0] * nums[1];
    console.log(sum);

}