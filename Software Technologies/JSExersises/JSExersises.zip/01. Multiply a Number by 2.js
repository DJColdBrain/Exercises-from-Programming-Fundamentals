/**
 * Created by DJColdBrain on 25-Jul-17.
 */

function e(num) {
    let a = num *2;
    console.log(a);
}