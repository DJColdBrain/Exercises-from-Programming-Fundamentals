/**
 * Created by DJColdBrain on 25-Jul-17.
 */

function a(nums) {

    for(let i = nums.length -1; i >=0; i--){
        console.log(nums[i]);
    }
}