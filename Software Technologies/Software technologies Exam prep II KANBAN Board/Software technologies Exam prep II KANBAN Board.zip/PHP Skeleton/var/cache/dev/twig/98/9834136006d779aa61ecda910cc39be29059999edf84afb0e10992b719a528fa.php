<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_09886c37796d81d574b2448cf2a22ea32da8dad546b69f22c376ce19a869ce97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce619015616ac32ed97fd89b38d5f4b822a926feabd41fc41fd95cc70048b3a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce619015616ac32ed97fd89b38d5f4b822a926feabd41fc41fd95cc70048b3a5->enter($__internal_ce619015616ac32ed97fd89b38d5f4b822a926feabd41fc41fd95cc70048b3a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_c7667b278fa5508be1b638e9789587b8e8da86990d8c89b466af78e3add5fccf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7667b278fa5508be1b638e9789587b8e8da86990d8c89b466af78e3add5fccf->enter($__internal_c7667b278fa5508be1b638e9789587b8e8da86990d8c89b466af78e3add5fccf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ce619015616ac32ed97fd89b38d5f4b822a926feabd41fc41fd95cc70048b3a5->leave($__internal_ce619015616ac32ed97fd89b38d5f4b822a926feabd41fc41fd95cc70048b3a5_prof);

        
        $__internal_c7667b278fa5508be1b638e9789587b8e8da86990d8c89b466af78e3add5fccf->leave($__internal_c7667b278fa5508be1b638e9789587b8e8da86990d8c89b466af78e3add5fccf_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_a3cc0d5f519c40e344da9584667c15a5c8d10f16cdc3b38d89ad28ebc69bf4d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3cc0d5f519c40e344da9584667c15a5c8d10f16cdc3b38d89ad28ebc69bf4d5->enter($__internal_a3cc0d5f519c40e344da9584667c15a5c8d10f16cdc3b38d89ad28ebc69bf4d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_fa52d4bdd6a661e1570f15d9478045f96ee0e4cdabe54948c2465265b1f0e4a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa52d4bdd6a661e1570f15d9478045f96ee0e4cdabe54948c2465265b1f0e4a3->enter($__internal_fa52d4bdd6a661e1570f15d9478045f96ee0e4cdabe54948c2465265b1f0e4a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_fa52d4bdd6a661e1570f15d9478045f96ee0e4cdabe54948c2465265b1f0e4a3->leave($__internal_fa52d4bdd6a661e1570f15d9478045f96ee0e4cdabe54948c2465265b1f0e4a3_prof);

        
        $__internal_a3cc0d5f519c40e344da9584667c15a5c8d10f16cdc3b38d89ad28ebc69bf4d5->leave($__internal_a3cc0d5f519c40e344da9584667c15a5c8d10f16cdc3b38d89ad28ebc69bf4d5_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5ed7a6f0b72256d405a95b19716c12275bf91403de9e2a0e7a454e9749f58c63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ed7a6f0b72256d405a95b19716c12275bf91403de9e2a0e7a454e9749f58c63->enter($__internal_5ed7a6f0b72256d405a95b19716c12275bf91403de9e2a0e7a454e9749f58c63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0476f4b53bc004fd4e91842a6415fdaf0fc489a82ce268a0298d157191ff1c05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0476f4b53bc004fd4e91842a6415fdaf0fc489a82ce268a0298d157191ff1c05->enter($__internal_0476f4b53bc004fd4e91842a6415fdaf0fc489a82ce268a0298d157191ff1c05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0476f4b53bc004fd4e91842a6415fdaf0fc489a82ce268a0298d157191ff1c05->leave($__internal_0476f4b53bc004fd4e91842a6415fdaf0fc489a82ce268a0298d157191ff1c05_prof);

        
        $__internal_5ed7a6f0b72256d405a95b19716c12275bf91403de9e2a0e7a454e9749f58c63->leave($__internal_5ed7a6f0b72256d405a95b19716c12275bf91403de9e2a0e7a454e9749f58c63_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2d9e436995a6a4d1ec3d5d93e674062ff4a7260b8b05ddff8938e62df6acc20a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2d9e436995a6a4d1ec3d5d93e674062ff4a7260b8b05ddff8938e62df6acc20a->enter($__internal_2d9e436995a6a4d1ec3d5d93e674062ff4a7260b8b05ddff8938e62df6acc20a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_50888a73498b26789971030e697bd30123039555b812c8f6b9a4808b8b68002c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50888a73498b26789971030e697bd30123039555b812c8f6b9a4808b8b68002c->enter($__internal_50888a73498b26789971030e697bd30123039555b812c8f6b9a4808b8b68002c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_50888a73498b26789971030e697bd30123039555b812c8f6b9a4808b8b68002c->leave($__internal_50888a73498b26789971030e697bd30123039555b812c8f6b9a4808b8b68002c_prof);

        
        $__internal_2d9e436995a6a4d1ec3d5d93e674062ff4a7260b8b05ddff8938e62df6acc20a->leave($__internal_2d9e436995a6a4d1ec3d5d93e674062ff4a7260b8b05ddff8938e62df6acc20a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "D:\\SoftUni\\Software technologies Exam prep II KANBAN Board\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
