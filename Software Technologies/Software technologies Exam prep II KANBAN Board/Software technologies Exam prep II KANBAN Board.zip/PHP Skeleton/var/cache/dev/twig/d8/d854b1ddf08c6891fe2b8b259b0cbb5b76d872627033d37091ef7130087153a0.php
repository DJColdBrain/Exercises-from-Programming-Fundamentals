<?php

/* task/edit.html.twig */
class __TwigTemplate_c7af4c078c9c3b53407fbc75de5ca1b656c30e1f5b369842f334fd9de17da0c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "task/edit.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fbeee7418398add9a5766bfa1c46092958f6cb3c618caa86be92be668af302a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fbeee7418398add9a5766bfa1c46092958f6cb3c618caa86be92be668af302a4->enter($__internal_fbeee7418398add9a5766bfa1c46092958f6cb3c618caa86be92be668af302a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/edit.html.twig"));

        $__internal_2eafbe0a01e5ce96207fa6f0fab1c8c9d190bafe8e1cb51f54e65ed11920f80b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2eafbe0a01e5ce96207fa6f0fab1c8c9d190bafe8e1cb51f54e65ed11920f80b->enter($__internal_2eafbe0a01e5ce96207fa6f0fab1c8c9d190bafe8e1cb51f54e65ed11920f80b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fbeee7418398add9a5766bfa1c46092958f6cb3c618caa86be92be668af302a4->leave($__internal_fbeee7418398add9a5766bfa1c46092958f6cb3c618caa86be92be668af302a4_prof);

        
        $__internal_2eafbe0a01e5ce96207fa6f0fab1c8c9d190bafe8e1cb51f54e65ed11920f80b->leave($__internal_2eafbe0a01e5ce96207fa6f0fab1c8c9d190bafe8e1cb51f54e65ed11920f80b_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_3529b8a846403bc65886b5d0f54270596ec0850c659e3f883394aeabff2b4613 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3529b8a846403bc65886b5d0f54270596ec0850c659e3f883394aeabff2b4613->enter($__internal_3529b8a846403bc65886b5d0f54270596ec0850c659e3f883394aeabff2b4613_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_a93fc3ffee436689a1a3f6289e99a42656af187e4823b8aaa3b51765a9307f4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a93fc3ffee436689a1a3f6289e99a42656af187e4823b8aaa3b51765a9307f4e->enter($__internal_a93fc3ffee436689a1a3f6289e99a42656af187e4823b8aaa3b51765a9307f4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <header>
        <h3>Edit Task</h3>
    </header>
    <form method=\"post\">
        <div>
            <label class=\"desc\" for=\"title\">Title</label>
            <div>
                <input id=\"title\" name=\"task[title]\" type=\"text\" class=\"field text fn\" size=\"8\" tabindex=\"1\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["task"] ?? $this->getContext($context, "task")), "title", array()), "html", null, true);
        echo "\" autofocus>
            </div>
        </div>

        <div>
            <fieldset>
                <legend class=\"desc\">
                    Status
                </legend>

                <div>
                    <div>
                        <input id=\"status1\" name=\"task[status]\" type=\"radio\" value=\"Open\" tabindex=\"2\" ";
        // line 23
        echo ((($this->getAttribute(($context["task"] ?? $this->getContext($context, "task")), "status", array()) == "Open")) ? ("checked") : (""));
        echo ">
                        <label class=\"choice\" for=\"status1\">Open</label>
                    </div>
                    <div>
                        <input id=\"status2\" name=\"task[status]\" type=\"radio\" value=\"In Progress\" tabindex=\"3\" ";
        // line 27
        echo ((($this->getAttribute(($context["task"] ?? $this->getContext($context, "task")), "status", array()) == "In Progress")) ? ("checked") : (""));
        echo ">
                        <label class=\"choice\" for=\"status2\">In Progress</label>
                    </div>
                    <div>
                        <input id=\"status3\" name=\"task[status]\" type=\"radio\" value=\"Finished\" tabindex=\"4\" ";
        // line 31
        echo ((($this->getAttribute(($context["task"] ?? $this->getContext($context, "task")), "status", array()) == "Finished")) ? ("checked") : (""));
        echo ">
                        <label class=\"choice\" for=\"status3\">Finished</label>
                    </div>
                </div>
            </fieldset>
        </div>

        <div>
            <div>
                <input class=\"button\" type=\"submit\" value=\"Submit\">
                <a class=\"button cancel\" href=\"/\">Cancel</a>
            </div>
        </div>

        ";
        // line 45
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
    </form>
";
        
        $__internal_a93fc3ffee436689a1a3f6289e99a42656af187e4823b8aaa3b51765a9307f4e->leave($__internal_a93fc3ffee436689a1a3f6289e99a42656af187e4823b8aaa3b51765a9307f4e_prof);

        
        $__internal_3529b8a846403bc65886b5d0f54270596ec0850c659e3f883394aeabff2b4613->leave($__internal_3529b8a846403bc65886b5d0f54270596ec0850c659e3f883394aeabff2b4613_prof);

    }

    public function getTemplateName()
    {
        return "task/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 45,  87 => 31,  80 => 27,  73 => 23,  58 => 11,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <header>
        <h3>Edit Task</h3>
    </header>
    <form method=\"post\">
        <div>
            <label class=\"desc\" for=\"title\">Title</label>
            <div>
                <input id=\"title\" name=\"task[title]\" type=\"text\" class=\"field text fn\" size=\"8\" tabindex=\"1\" value=\"{{ task.title }}\" autofocus>
            </div>
        </div>

        <div>
            <fieldset>
                <legend class=\"desc\">
                    Status
                </legend>

                <div>
                    <div>
                        <input id=\"status1\" name=\"task[status]\" type=\"radio\" value=\"Open\" tabindex=\"2\" {{ task.status == 'Open' ? 'checked' : '' }}>
                        <label class=\"choice\" for=\"status1\">Open</label>
                    </div>
                    <div>
                        <input id=\"status2\" name=\"task[status]\" type=\"radio\" value=\"In Progress\" tabindex=\"3\" {{ task.status == 'In Progress' ? 'checked' : '' }}>
                        <label class=\"choice\" for=\"status2\">In Progress</label>
                    </div>
                    <div>
                        <input id=\"status3\" name=\"task[status]\" type=\"radio\" value=\"Finished\" tabindex=\"4\" {{ task.status == 'Finished' ? 'checked' : '' }}>
                        <label class=\"choice\" for=\"status3\">Finished</label>
                    </div>
                </div>
            </fieldset>
        </div>

        <div>
            <div>
                <input class=\"button\" type=\"submit\" value=\"Submit\">
                <a class=\"button cancel\" href=\"/\">Cancel</a>
            </div>
        </div>

        {{ form_row(form._token) }}
    </form>
{% endblock %}", "task/edit.html.twig", "D:\\SoftUni\\Software technologies Exam prep II KANBAN Board\\PHP Skeleton\\app\\Resources\\views\\task\\edit.html.twig");
    }
}
