<?php

/* task/create.html.twig */
class __TwigTemplate_6e5eea0179c0e14d539c7b4381c84bf8b9ace588f2b99ef32d8733d57eb34b9a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "task/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7d0699c494e8890e99c10a369e91a336c98f44b824af9efabac7df586b16a86 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7d0699c494e8890e99c10a369e91a336c98f44b824af9efabac7df586b16a86->enter($__internal_c7d0699c494e8890e99c10a369e91a336c98f44b824af9efabac7df586b16a86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/create.html.twig"));

        $__internal_ac75259e604bc4456aa428fbfc6afe7e2e67f5b73bb117b2b23764bca3d85991 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac75259e604bc4456aa428fbfc6afe7e2e67f5b73bb117b2b23764bca3d85991->enter($__internal_ac75259e604bc4456aa428fbfc6afe7e2e67f5b73bb117b2b23764bca3d85991_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c7d0699c494e8890e99c10a369e91a336c98f44b824af9efabac7df586b16a86->leave($__internal_c7d0699c494e8890e99c10a369e91a336c98f44b824af9efabac7df586b16a86_prof);

        
        $__internal_ac75259e604bc4456aa428fbfc6afe7e2e67f5b73bb117b2b23764bca3d85991->leave($__internal_ac75259e604bc4456aa428fbfc6afe7e2e67f5b73bb117b2b23764bca3d85991_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_0474d35ee0ee5ac0eef88f669eb7919b187913ef21875c4ca7e21121e124f3f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0474d35ee0ee5ac0eef88f669eb7919b187913ef21875c4ca7e21121e124f3f6->enter($__internal_0474d35ee0ee5ac0eef88f669eb7919b187913ef21875c4ca7e21121e124f3f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_8b40f5acaccf61b221a931f8f1026918b53f3a1cb855777576e580e07baf4221 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b40f5acaccf61b221a931f8f1026918b53f3a1cb855777576e580e07baf4221->enter($__internal_8b40f5acaccf61b221a931f8f1026918b53f3a1cb855777576e580e07baf4221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <header>
        <h3>Create New Task</h3>
    </header>
    <form method=\"post\">
        <div>
            <label class=\"desc\" for=\"title\">Title</label>
            <div>
                <input id=\"title\" name=\"task[title]\" type=\"text\" class=\"field text fn\" value=\"\" size=\"8\" tabindex=\"1\"
                       autofocus>
            </div>
        </div>

        <div>
            <fieldset>
                <legend class=\"desc\">
                    Status
                </legend>

                <div>
                    <div>
                        <input id=\"status1\" name=\"task[status]\" type=\"radio\" value=\"Open\" tabindex=\"2\" checked>
                        <label class=\"choice\" for=\"status1\">Open</label>
                    </div>
                    <div>
                        <input id=\"status2\" name=\"task[status]\" type=\"radio\" value=\"In Progress\" tabindex=\"3\">
                        <label class=\"choice\" for=\"status2\">In Progress</label>
                    </div>
                    <div>
                        <input id=\"status3\" name=\"task[status]\" type=\"radio\" value=\"Finished\" tabindex=\"4\">
                        <label class=\"choice\" for=\"status3\">Finished</label>
                    </div>
                </div>
            </fieldset>
        </div>

        <div>
            <div>
                <input class=\"button\" type=\"submit\" value=\"Submit\">
                <a class=\"button cancel\" href=\"/\">Cancel</a>
            </div>
        </div>

        ";
        // line 46
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
    </form>
";
        
        $__internal_8b40f5acaccf61b221a931f8f1026918b53f3a1cb855777576e580e07baf4221->leave($__internal_8b40f5acaccf61b221a931f8f1026918b53f3a1cb855777576e580e07baf4221_prof);

        
        $__internal_0474d35ee0ee5ac0eef88f669eb7919b187913ef21875c4ca7e21121e124f3f6->leave($__internal_0474d35ee0ee5ac0eef88f669eb7919b187913ef21875c4ca7e21121e124f3f6_prof);

    }

    public function getTemplateName()
    {
        return "task/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 46,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <header>
        <h3>Create New Task</h3>
    </header>
    <form method=\"post\">
        <div>
            <label class=\"desc\" for=\"title\">Title</label>
            <div>
                <input id=\"title\" name=\"task[title]\" type=\"text\" class=\"field text fn\" value=\"\" size=\"8\" tabindex=\"1\"
                       autofocus>
            </div>
        </div>

        <div>
            <fieldset>
                <legend class=\"desc\">
                    Status
                </legend>

                <div>
                    <div>
                        <input id=\"status1\" name=\"task[status]\" type=\"radio\" value=\"Open\" tabindex=\"2\" checked>
                        <label class=\"choice\" for=\"status1\">Open</label>
                    </div>
                    <div>
                        <input id=\"status2\" name=\"task[status]\" type=\"radio\" value=\"In Progress\" tabindex=\"3\">
                        <label class=\"choice\" for=\"status2\">In Progress</label>
                    </div>
                    <div>
                        <input id=\"status3\" name=\"task[status]\" type=\"radio\" value=\"Finished\" tabindex=\"4\">
                        <label class=\"choice\" for=\"status3\">Finished</label>
                    </div>
                </div>
            </fieldset>
        </div>

        <div>
            <div>
                <input class=\"button\" type=\"submit\" value=\"Submit\">
                <a class=\"button cancel\" href=\"/\">Cancel</a>
            </div>
        </div>

        {{ form_row(form._token) }}
    </form>
{% endblock %}", "task/create.html.twig", "D:\\SoftUni\\Software technologies Exam prep II KANBAN Board\\PHP Skeleton\\app\\Resources\\views\\task\\create.html.twig");
    }
}
