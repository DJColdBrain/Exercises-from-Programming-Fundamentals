<?php

/* task/index.html.twig */
class __TwigTemplate_cb326ced4e270ced78a57c392b98cf77dedd0df51ed766e8feda828991fe0b71 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "task/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d43642d16ed787f04f4f28d1cbd717b2d58192246884d29e1c3561244e4f49e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d43642d16ed787f04f4f28d1cbd717b2d58192246884d29e1c3561244e4f49e->enter($__internal_7d43642d16ed787f04f4f28d1cbd717b2d58192246884d29e1c3561244e4f49e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/index.html.twig"));

        $__internal_284d2f0bc8ba4b80b45713c75a816592525893ac1a000687af21a690d9730ff5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_284d2f0bc8ba4b80b45713c75a816592525893ac1a000687af21a690d9730ff5->enter($__internal_284d2f0bc8ba4b80b45713c75a816592525893ac1a000687af21a690d9730ff5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7d43642d16ed787f04f4f28d1cbd717b2d58192246884d29e1c3561244e4f49e->leave($__internal_7d43642d16ed787f04f4f28d1cbd717b2d58192246884d29e1c3561244e4f49e_prof);

        
        $__internal_284d2f0bc8ba4b80b45713c75a816592525893ac1a000687af21a690d9730ff5->leave($__internal_284d2f0bc8ba4b80b45713c75a816592525893ac1a000687af21a690d9730ff5_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_2e982b8261e0d5a979aad666b3239f094a1638ca0c5b279ec3964cd4c7aa320a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e982b8261e0d5a979aad666b3239f094a1638ca0c5b279ec3964cd4c7aa320a->enter($__internal_2e982b8261e0d5a979aad666b3239f094a1638ca0c5b279ec3964cd4c7aa320a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_cdac98c279e38e2367a54e6a803c3c63cea7fc65135bdca37183e309a59ef23c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdac98c279e38e2367a54e6a803c3c63cea7fc65135bdca37183e309a59ef23c->enter($__internal_cdac98c279e38e2367a54e6a803c3c63cea7fc65135bdca37183e309a59ef23c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container\">
        <a class=\"button\" href=\"http://localhost:8000/create\">Create New Task</a>
    </div>
    <div class=\"tasks container\">
        <header>
            <div class=\"column header open\">Open</div>
            <div class=\"column header inProgress\">In progress</div>
            <div class=\"column header finished\">Finished</div>
        </header>
        <ul class=\"column open\">
            ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["openTasks"] ?? $this->getContext($context, "openTasks")));
        foreach ($context['_seq'] as $context["_key"] => $context["task"]) {
            // line 15
            echo "                <li>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["task"], "title", array()), "html", null, true);
            echo "
                    <a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit", array("id" => $this->getAttribute($context["task"], "id", array()))), "html", null, true);
            echo "\" class=\"icon edit\"></a>
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['task'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "        </ul>
        <ul class=\"column inProgress\">
            ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["inProgressTasks"] ?? $this->getContext($context, "inProgressTasks")));
        foreach ($context['_seq'] as $context["_key"] => $context["task"]) {
            // line 22
            echo "                <li>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["task"], "title", array()), "html", null, true);
            echo "
                    <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit", array("id" => $this->getAttribute($context["task"], "id", array()))), "html", null, true);
            echo "\" class=\"icon edit\"></a>
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['task'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "        </ul>
        <ul class=\"column finished\">
            ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["finishedTasks"] ?? $this->getContext($context, "finishedTasks")));
        foreach ($context['_seq'] as $context["_key"] => $context["task"]) {
            // line 29
            echo "                <li>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["task"], "title", array()), "html", null, true);
            echo "
                    <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("edit", array("id" => $this->getAttribute($context["task"], "id", array()))), "html", null, true);
            echo "\" class=\"icon edit\"></a>
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['task'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "        </ul>
    </div>
";
        
        $__internal_cdac98c279e38e2367a54e6a803c3c63cea7fc65135bdca37183e309a59ef23c->leave($__internal_cdac98c279e38e2367a54e6a803c3c63cea7fc65135bdca37183e309a59ef23c_prof);

        
        $__internal_2e982b8261e0d5a979aad666b3239f094a1638ca0c5b279ec3964cd4c7aa320a->leave($__internal_2e982b8261e0d5a979aad666b3239f094a1638ca0c5b279ec3964cd4c7aa320a_prof);

    }

    public function getTemplateName()
    {
        return "task/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 33,  114 => 30,  109 => 29,  105 => 28,  101 => 26,  92 => 23,  87 => 22,  83 => 21,  79 => 19,  70 => 16,  65 => 15,  61 => 14,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <div class=\"container\">
        <a class=\"button\" href=\"http://localhost:8000/create\">Create New Task</a>
    </div>
    <div class=\"tasks container\">
        <header>
            <div class=\"column header open\">Open</div>
            <div class=\"column header inProgress\">In progress</div>
            <div class=\"column header finished\">Finished</div>
        </header>
        <ul class=\"column open\">
            {% for task in openTasks %}
                <li>{{ task.title }}
                    <a href=\"{{ path('edit', {id: task.id}) }}\" class=\"icon edit\"></a>
                </li>
            {% endfor %}
        </ul>
        <ul class=\"column inProgress\">
            {% for task in inProgressTasks %}
                <li>{{ task.title }}
                    <a href=\"{{ path('edit', {id: task.id}) }}\" class=\"icon edit\"></a>
                </li>
            {% endfor %}
        </ul>
        <ul class=\"column finished\">
            {% for task in finishedTasks %}
                <li>{{ task.title }}
                    <a href=\"{{ path('edit', {id: task.id}) }}\" class=\"icon edit\"></a>
                </li>
            {% endfor %}
        </ul>
    </div>
{% endblock %}", "task/index.html.twig", "D:\\SoftUni\\Software technologies Exam prep II KANBAN Board\\PHP Skeleton\\app\\Resources\\views\\task\\index.html.twig");
    }
}
