<?php

/* base.html.twig */
class __TwigTemplate_93e2499d03c6402ea1e3906495568257ed0120721f7f5badb0e11600e82927c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d00765bbc50be26db95fb4e53ea800c77b2d626f3cd5ff9665c9e1c4f8edde05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d00765bbc50be26db95fb4e53ea800c77b2d626f3cd5ff9665c9e1c4f8edde05->enter($__internal_d00765bbc50be26db95fb4e53ea800c77b2d626f3cd5ff9665c9e1c4f8edde05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_c2af35ead37ee5556ff8b676cc8812b62151a4cb923c8afb5769671d94244be2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2af35ead37ee5556ff8b676cc8812b62151a4cb923c8afb5769671d94244be2->enter($__internal_c2af35ead37ee5556ff8b676cc8812b62151a4cb923c8afb5769671d94244be2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 18
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 21
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">
";
        // line 22
        $this->displayBlock('body', $context, $blocks);
        // line 25
        echo "</body>
</html>
";
        
        $__internal_d00765bbc50be26db95fb4e53ea800c77b2d626f3cd5ff9665c9e1c4f8edde05->leave($__internal_d00765bbc50be26db95fb4e53ea800c77b2d626f3cd5ff9665c9e1c4f8edde05_prof);

        
        $__internal_c2af35ead37ee5556ff8b676cc8812b62151a4cb923c8afb5769671d94244be2->leave($__internal_c2af35ead37ee5556ff8b676cc8812b62151a4cb923c8afb5769671d94244be2_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_0abc36f44bced25d4a471424eb387b3b1803662e74bd19e60bb6e7c2d76bc5e7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0abc36f44bced25d4a471424eb387b3b1803662e74bd19e60bb6e7c2d76bc5e7->enter($__internal_0abc36f44bced25d4a471424eb387b3b1803662e74bd19e60bb6e7c2d76bc5e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_21bfea9d90e757e7daab63eb05c91b1d9c9b799c9e931f9baf79fea08eb52897 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_21bfea9d90e757e7daab63eb05c91b1d9c9b799c9e931f9baf79fea08eb52897->enter($__internal_21bfea9d90e757e7daab63eb05c91b1d9c9b799c9e931f9baf79fea08eb52897_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "TODO List";
        
        $__internal_21bfea9d90e757e7daab63eb05c91b1d9c9b799c9e931f9baf79fea08eb52897->leave($__internal_21bfea9d90e757e7daab63eb05c91b1d9c9b799c9e931f9baf79fea08eb52897_prof);

        
        $__internal_0abc36f44bced25d4a471424eb387b3b1803662e74bd19e60bb6e7c2d76bc5e7->leave($__internal_0abc36f44bced25d4a471424eb387b3b1803662e74bd19e60bb6e7c2d76bc5e7_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3b1ea621350466a275ace86085b1c57e978bfe600c982bbf20f10ec9a972be89 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b1ea621350466a275ace86085b1c57e978bfe600c982bbf20f10ec9a972be89->enter($__internal_3b1ea621350466a275ace86085b1c57e978bfe600c982bbf20f10ec9a972be89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_37c9d68e5f7c07fc51e56b52ce37dd147f8d92db7b6a8c267069ed62ba904253 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37c9d68e5f7c07fc51e56b52ce37dd147f8d92db7b6a8c267069ed62ba904253->enter($__internal_37c9d68e5f7c07fc51e56b52ce37dd147f8d92db7b6a8c267069ed62ba904253_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        ";
        // line 14
        echo "        ";
        // line 15
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/index-style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/form-style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_37c9d68e5f7c07fc51e56b52ce37dd147f8d92db7b6a8c267069ed62ba904253->leave($__internal_37c9d68e5f7c07fc51e56b52ce37dd147f8d92db7b6a8c267069ed62ba904253_prof);

        
        $__internal_3b1ea621350466a275ace86085b1c57e978bfe600c982bbf20f10ec9a972be89->leave($__internal_3b1ea621350466a275ace86085b1c57e978bfe600c982bbf20f10ec9a972be89_prof);

    }

    // line 21
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_3533960e941d9394aaaa3ea379cae7a7ebc16f52114c441f74be2bf807653f62 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3533960e941d9394aaaa3ea379cae7a7ebc16f52114c441f74be2bf807653f62->enter($__internal_3533960e941d9394aaaa3ea379cae7a7ebc16f52114c441f74be2bf807653f62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_df342e93553e3ca36714538196e27761072b02b293d275d2bf446dd064878fe5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df342e93553e3ca36714538196e27761072b02b293d275d2bf446dd064878fe5->enter($__internal_df342e93553e3ca36714538196e27761072b02b293d275d2bf446dd064878fe5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_df342e93553e3ca36714538196e27761072b02b293d275d2bf446dd064878fe5->leave($__internal_df342e93553e3ca36714538196e27761072b02b293d275d2bf446dd064878fe5_prof);

        
        $__internal_3533960e941d9394aaaa3ea379cae7a7ebc16f52114c441f74be2bf807653f62->leave($__internal_3533960e941d9394aaaa3ea379cae7a7ebc16f52114c441f74be2bf807653f62_prof);

    }

    // line 22
    public function block_body($context, array $blocks = array())
    {
        $__internal_5a917d66508b2ca3b579f7a8854dbdc956a7fc8567f1982e347288920365ca8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a917d66508b2ca3b579f7a8854dbdc956a7fc8567f1982e347288920365ca8f->enter($__internal_5a917d66508b2ca3b579f7a8854dbdc956a7fc8567f1982e347288920365ca8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a5237a16aee0543ab2b96aeeb89ff1b04bc79be5e7834358da3f88877f2ce03d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5237a16aee0543ab2b96aeeb89ff1b04bc79be5e7834358da3f88877f2ce03d->enter($__internal_a5237a16aee0543ab2b96aeeb89ff1b04bc79be5e7834358da3f88877f2ce03d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 23
        echo "    ";
        $this->displayBlock('main', $context, $blocks);
        
        $__internal_a5237a16aee0543ab2b96aeeb89ff1b04bc79be5e7834358da3f88877f2ce03d->leave($__internal_a5237a16aee0543ab2b96aeeb89ff1b04bc79be5e7834358da3f88877f2ce03d_prof);

        
        $__internal_5a917d66508b2ca3b579f7a8854dbdc956a7fc8567f1982e347288920365ca8f->leave($__internal_5a917d66508b2ca3b579f7a8854dbdc956a7fc8567f1982e347288920365ca8f_prof);

    }

    public function block_main($context, array $blocks = array())
    {
        $__internal_01389d6f6905640684cf4c572b098db06e79f1c57fb69697b5c970f68cf5b5f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01389d6f6905640684cf4c572b098db06e79f1c57fb69697b5c970f68cf5b5f8->enter($__internal_01389d6f6905640684cf4c572b098db06e79f1c57fb69697b5c970f68cf5b5f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_ff083c42c0161ce8c50fb03ae2de484635010bb03d097491f9555a14370eed4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff083c42c0161ce8c50fb03ae2de484635010bb03d097491f9555a14370eed4d->enter($__internal_ff083c42c0161ce8c50fb03ae2de484635010bb03d097491f9555a14370eed4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_ff083c42c0161ce8c50fb03ae2de484635010bb03d097491f9555a14370eed4d->leave($__internal_ff083c42c0161ce8c50fb03ae2de484635010bb03d097491f9555a14370eed4d_prof);

        
        $__internal_01389d6f6905640684cf4c572b098db06e79f1c57fb69697b5c970f68cf5b5f8->leave($__internal_01389d6f6905640684cf4c572b098db06e79f1c57fb69697b5c970f68cf5b5f8_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 23,  133 => 22,  116 => 21,  104 => 16,  99 => 15,  97 => 14,  95 => 13,  86 => 12,  68 => 11,  56 => 25,  54 => 22,  50 => 21,  43 => 18,  41 => 12,  37 => 11,  30 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}TODO List{% endblock %}</title>
    {% block stylesheets %}
        {#<link rel=\"stylesheet\" href=\"{{ asset('css/reset-style.css') }}\">;#}
        {#<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">#}
        <link rel=\"stylesheet\" href=\"{{ asset('css/index-style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/form-style.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">
{% block body %}
    {% block main %}{% endblock %}
{% endblock %}
</body>
</html>
", "base.html.twig", "D:\\SoftUni\\Software technologies Exam prep II KANBAN Board\\PHP Skeleton\\app\\Resources\\views\\base.html.twig");
    }
}
