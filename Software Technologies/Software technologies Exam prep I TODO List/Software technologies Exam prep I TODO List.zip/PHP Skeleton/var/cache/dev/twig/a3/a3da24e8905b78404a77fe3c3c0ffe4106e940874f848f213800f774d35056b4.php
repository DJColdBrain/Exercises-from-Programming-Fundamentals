<?php

/* base.html.twig */
class __TwigTemplate_93e2499d03c6402ea1e3906495568257ed0120721f7f5badb0e11600e82927c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d5ac0ef22bf2b4c3c9d261965fff294f4aa7c0168db862c5990351fe43d2d533 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5ac0ef22bf2b4c3c9d261965fff294f4aa7c0168db862c5990351fe43d2d533->enter($__internal_d5ac0ef22bf2b4c3c9d261965fff294f4aa7c0168db862c5990351fe43d2d533_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_2486ce6c4f43c5c7fc6d2dc230af2ca2be3076492b4be92bca091944e4bbf29b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2486ce6c4f43c5c7fc6d2dc230af2ca2be3076492b4be92bca091944e4bbf29b->enter($__internal_2486ce6c4f43c5c7fc6d2dc230af2ca2be3076492b4be92bca091944e4bbf29b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 19
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 22
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">
";
        // line 23
        $this->displayBlock('body', $context, $blocks);
        // line 26
        echo "</body>
</html>
";
        
        $__internal_d5ac0ef22bf2b4c3c9d261965fff294f4aa7c0168db862c5990351fe43d2d533->leave($__internal_d5ac0ef22bf2b4c3c9d261965fff294f4aa7c0168db862c5990351fe43d2d533_prof);

        
        $__internal_2486ce6c4f43c5c7fc6d2dc230af2ca2be3076492b4be92bca091944e4bbf29b->leave($__internal_2486ce6c4f43c5c7fc6d2dc230af2ca2be3076492b4be92bca091944e4bbf29b_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_1cd486e297fc924e9f9499fa5ac25852440bbce759fb3388d9f92e8b20521a3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cd486e297fc924e9f9499fa5ac25852440bbce759fb3388d9f92e8b20521a3c->enter($__internal_1cd486e297fc924e9f9499fa5ac25852440bbce759fb3388d9f92e8b20521a3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0854348e7945f7835fd777453363fc7065ecd977cbf7557dc71fe5620b5ff94c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0854348e7945f7835fd777453363fc7065ecd977cbf7557dc71fe5620b5ff94c->enter($__internal_0854348e7945f7835fd777453363fc7065ecd977cbf7557dc71fe5620b5ff94c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "TODO List";
        
        $__internal_0854348e7945f7835fd777453363fc7065ecd977cbf7557dc71fe5620b5ff94c->leave($__internal_0854348e7945f7835fd777453363fc7065ecd977cbf7557dc71fe5620b5ff94c_prof);

        
        $__internal_1cd486e297fc924e9f9499fa5ac25852440bbce759fb3388d9f92e8b20521a3c->leave($__internal_1cd486e297fc924e9f9499fa5ac25852440bbce759fb3388d9f92e8b20521a3c_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_63bd0e5fa47be34b628011a98e178f9de591168b5abc494cf62b509a11a56eb4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63bd0e5fa47be34b628011a98e178f9de591168b5abc494cf62b509a11a56eb4->enter($__internal_63bd0e5fa47be34b628011a98e178f9de591168b5abc494cf62b509a11a56eb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_7c0500516228ab6d962d34e6393f6f648fc85697b6f5509312df104224bb01b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c0500516228ab6d962d34e6393f6f648fc85697b6f5509312df104224bb01b6->enter($__internal_7c0500516228ab6d962d34e6393f6f648fc85697b6f5509312df104224bb01b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        ";
        // line 14
        echo "        ";
        // line 15
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/index-style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/create-style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/delete-style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_7c0500516228ab6d962d34e6393f6f648fc85697b6f5509312df104224bb01b6->leave($__internal_7c0500516228ab6d962d34e6393f6f648fc85697b6f5509312df104224bb01b6_prof);

        
        $__internal_63bd0e5fa47be34b628011a98e178f9de591168b5abc494cf62b509a11a56eb4->leave($__internal_63bd0e5fa47be34b628011a98e178f9de591168b5abc494cf62b509a11a56eb4_prof);

    }

    // line 22
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_7dcc7435d0c4fe415d8c29e6550a154b5168adbcb64cdb14574e545dd7316d51 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7dcc7435d0c4fe415d8c29e6550a154b5168adbcb64cdb14574e545dd7316d51->enter($__internal_7dcc7435d0c4fe415d8c29e6550a154b5168adbcb64cdb14574e545dd7316d51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_269f536a448d9738f8f5bfc622b50741a2005c929b4cb8cc167f48d70b41e7d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_269f536a448d9738f8f5bfc622b50741a2005c929b4cb8cc167f48d70b41e7d5->enter($__internal_269f536a448d9738f8f5bfc622b50741a2005c929b4cb8cc167f48d70b41e7d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_269f536a448d9738f8f5bfc622b50741a2005c929b4cb8cc167f48d70b41e7d5->leave($__internal_269f536a448d9738f8f5bfc622b50741a2005c929b4cb8cc167f48d70b41e7d5_prof);

        
        $__internal_7dcc7435d0c4fe415d8c29e6550a154b5168adbcb64cdb14574e545dd7316d51->leave($__internal_7dcc7435d0c4fe415d8c29e6550a154b5168adbcb64cdb14574e545dd7316d51_prof);

    }

    // line 23
    public function block_body($context, array $blocks = array())
    {
        $__internal_ee6a976b83f0707a449c098c831215288e037674aae1ee305d7f33d61084f57e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee6a976b83f0707a449c098c831215288e037674aae1ee305d7f33d61084f57e->enter($__internal_ee6a976b83f0707a449c098c831215288e037674aae1ee305d7f33d61084f57e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6c7bbf2f5fd2f5b0a00b993a3029813ae461fc8600f00e54a40cdf7f68b8d879 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c7bbf2f5fd2f5b0a00b993a3029813ae461fc8600f00e54a40cdf7f68b8d879->enter($__internal_6c7bbf2f5fd2f5b0a00b993a3029813ae461fc8600f00e54a40cdf7f68b8d879_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 24
        echo "    ";
        $this->displayBlock('main', $context, $blocks);
        
        $__internal_6c7bbf2f5fd2f5b0a00b993a3029813ae461fc8600f00e54a40cdf7f68b8d879->leave($__internal_6c7bbf2f5fd2f5b0a00b993a3029813ae461fc8600f00e54a40cdf7f68b8d879_prof);

        
        $__internal_ee6a976b83f0707a449c098c831215288e037674aae1ee305d7f33d61084f57e->leave($__internal_ee6a976b83f0707a449c098c831215288e037674aae1ee305d7f33d61084f57e_prof);

    }

    public function block_main($context, array $blocks = array())
    {
        $__internal_527a69ac95b4ad61d49f348fdc0f41bbcd2bcb615ab72838d18d562f80b7b3b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_527a69ac95b4ad61d49f348fdc0f41bbcd2bcb615ab72838d18d562f80b7b3b4->enter($__internal_527a69ac95b4ad61d49f348fdc0f41bbcd2bcb615ab72838d18d562f80b7b3b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_f3831c065000b8e26ab3e2931b7cc8cee8dc0549a006949cd161ebbd39a232ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3831c065000b8e26ab3e2931b7cc8cee8dc0549a006949cd161ebbd39a232ca->enter($__internal_f3831c065000b8e26ab3e2931b7cc8cee8dc0549a006949cd161ebbd39a232ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_f3831c065000b8e26ab3e2931b7cc8cee8dc0549a006949cd161ebbd39a232ca->leave($__internal_f3831c065000b8e26ab3e2931b7cc8cee8dc0549a006949cd161ebbd39a232ca_prof);

        
        $__internal_527a69ac95b4ad61d49f348fdc0f41bbcd2bcb615ab72838d18d562f80b7b3b4->leave($__internal_527a69ac95b4ad61d49f348fdc0f41bbcd2bcb615ab72838d18d562f80b7b3b4_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 24,  137 => 23,  120 => 22,  108 => 17,  104 => 16,  99 => 15,  97 => 14,  95 => 13,  86 => 12,  68 => 11,  56 => 26,  54 => 23,  50 => 22,  43 => 19,  41 => 12,  37 => 11,  30 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}TODO List{% endblock %}</title>
    {% block stylesheets %}
        {#<link rel=\"stylesheet\" href=\"{{ asset('css/reset-style.css') }}\">;#}
        {#<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">#}
        <link rel=\"stylesheet\" href=\"{{ asset('css/index-style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/create-style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/delete-style.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">
{% block body %}
    {% block main %}{% endblock %}
{% endblock %}
</body>
</html>
", "base.html.twig", "D:\\SoftUni\\Software technologies Exam preparations\\PHP Skeleton\\app\\Resources\\views\\base.html.twig");
    }
}
