<?php

/* task/index.html.twig */
class __TwigTemplate_cb326ced4e270ced78a57c392b98cf77dedd0df51ed766e8feda828991fe0b71 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "task/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c48bfab8c896c8bffbf338dfa990f590501f071b084604f45131152bd8e123d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c48bfab8c896c8bffbf338dfa990f590501f071b084604f45131152bd8e123d->enter($__internal_9c48bfab8c896c8bffbf338dfa990f590501f071b084604f45131152bd8e123d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/index.html.twig"));

        $__internal_4a0940ae169a4450ea2b8ae75ab7d87305f40f2c8b2de1771a17862af3906340 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a0940ae169a4450ea2b8ae75ab7d87305f40f2c8b2de1771a17862af3906340->enter($__internal_4a0940ae169a4450ea2b8ae75ab7d87305f40f2c8b2de1771a17862af3906340_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c48bfab8c896c8bffbf338dfa990f590501f071b084604f45131152bd8e123d->leave($__internal_9c48bfab8c896c8bffbf338dfa990f590501f071b084604f45131152bd8e123d_prof);

        
        $__internal_4a0940ae169a4450ea2b8ae75ab7d87305f40f2c8b2de1771a17862af3906340->leave($__internal_4a0940ae169a4450ea2b8ae75ab7d87305f40f2c8b2de1771a17862af3906340_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_59cdc20cdb8766de0cbaeb950ca1167c170f398638252c0b27b41e2e062a7dd7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59cdc20cdb8766de0cbaeb950ca1167c170f398638252c0b27b41e2e062a7dd7->enter($__internal_59cdc20cdb8766de0cbaeb950ca1167c170f398638252c0b27b41e2e062a7dd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_474032cb24ad556af21daf34fea2b00171937d4ac8b91eb4495cbbd4989e3975 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_474032cb24ad556af21daf34fea2b00171937d4ac8b91eb4495cbbd4989e3975->enter($__internal_474032cb24ad556af21daf34fea2b00171937d4ac8b91eb4495cbbd4989e3975_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<section class=\"home\">
    <h2>Tasks:</h2>
    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["tasks"] ?? $this->getContext($context, "tasks")));
        foreach ($context['_seq'] as $context["_key"] => $context["task"]) {
            // line 7
            echo "    <article>
        <a href=\"";
            // line 8
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete", array("id" => $this->getAttribute($context["task"], "id", array()))), "html", null, true);
            echo "\" class=\"fa fa-window-close\">X</a>
        <h3>";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($context["task"], "title", array()), "html", null, true);
            echo "</h3>
        <p>";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["task"], "comments", array()), "html", null, true);
            echo "</p>
    </article>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['task'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "    <a id=\"create-button\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create");
        echo "\">Create New</a>
    ";
        // line 15
        echo "</section>
";
        
        $__internal_474032cb24ad556af21daf34fea2b00171937d4ac8b91eb4495cbbd4989e3975->leave($__internal_474032cb24ad556af21daf34fea2b00171937d4ac8b91eb4495cbbd4989e3975_prof);

        
        $__internal_59cdc20cdb8766de0cbaeb950ca1167c170f398638252c0b27b41e2e062a7dd7->leave($__internal_59cdc20cdb8766de0cbaeb950ca1167c170f398638252c0b27b41e2e062a7dd7_prof);

    }

    public function getTemplateName()
    {
        return "task/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 15,  77 => 13,  68 => 10,  64 => 9,  60 => 8,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<section class=\"home\">
    <h2>Tasks:</h2>
    {% for task in tasks %}
    <article>
        <a href=\"{{ path('delete', {id: task.id}) }}\" class=\"fa fa-window-close\">X</a>
        <h3>{{ task.title }}</h3>
        <p>{{ task.comments }}</p>
    </article>
    {% endfor  %}
    <a id=\"create-button\" href=\"{{ path('create') }}\">Create New</a>
    {#<button>Create New</button>#}
</section>
{% endblock %}", "task/index.html.twig", "D:\\SoftUni\\Software technologies Exam preparations\\PHP Skeleton\\app\\Resources\\views\\task\\index.html.twig");
    }
}
