<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_09886c37796d81d574b2448cf2a22ea32da8dad546b69f22c376ce19a869ce97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_48bc7a63f35a920ab2e5a8f9291037a9dfa7475d30a3bdeef1fd606f92267782 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_48bc7a63f35a920ab2e5a8f9291037a9dfa7475d30a3bdeef1fd606f92267782->enter($__internal_48bc7a63f35a920ab2e5a8f9291037a9dfa7475d30a3bdeef1fd606f92267782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_ce0d41cc6d14e896b4810031923dc57f7a24c99fa78c3281978989a2926afbf3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce0d41cc6d14e896b4810031923dc57f7a24c99fa78c3281978989a2926afbf3->enter($__internal_ce0d41cc6d14e896b4810031923dc57f7a24c99fa78c3281978989a2926afbf3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_48bc7a63f35a920ab2e5a8f9291037a9dfa7475d30a3bdeef1fd606f92267782->leave($__internal_48bc7a63f35a920ab2e5a8f9291037a9dfa7475d30a3bdeef1fd606f92267782_prof);

        
        $__internal_ce0d41cc6d14e896b4810031923dc57f7a24c99fa78c3281978989a2926afbf3->leave($__internal_ce0d41cc6d14e896b4810031923dc57f7a24c99fa78c3281978989a2926afbf3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ae86d91fe28a311559cf130cfbee62845fc786545f7fa9e559259365819a4399 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae86d91fe28a311559cf130cfbee62845fc786545f7fa9e559259365819a4399->enter($__internal_ae86d91fe28a311559cf130cfbee62845fc786545f7fa9e559259365819a4399_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_ccb208c15014ee7b0dc9c8c2ded5b35df8a2994148e2eeea88406fb4c7f6e9e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccb208c15014ee7b0dc9c8c2ded5b35df8a2994148e2eeea88406fb4c7f6e9e3->enter($__internal_ccb208c15014ee7b0dc9c8c2ded5b35df8a2994148e2eeea88406fb4c7f6e9e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_ccb208c15014ee7b0dc9c8c2ded5b35df8a2994148e2eeea88406fb4c7f6e9e3->leave($__internal_ccb208c15014ee7b0dc9c8c2ded5b35df8a2994148e2eeea88406fb4c7f6e9e3_prof);

        
        $__internal_ae86d91fe28a311559cf130cfbee62845fc786545f7fa9e559259365819a4399->leave($__internal_ae86d91fe28a311559cf130cfbee62845fc786545f7fa9e559259365819a4399_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_083de0e7118f3b47ef5bc2948bd25fb0bdeb3fc572d19fd2180c0f08c890deb2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_083de0e7118f3b47ef5bc2948bd25fb0bdeb3fc572d19fd2180c0f08c890deb2->enter($__internal_083de0e7118f3b47ef5bc2948bd25fb0bdeb3fc572d19fd2180c0f08c890deb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_9240baf6d3ed9ac55846b4e84a5f98703fea7208906ca565e5ac5e90c621c816 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9240baf6d3ed9ac55846b4e84a5f98703fea7208906ca565e5ac5e90c621c816->enter($__internal_9240baf6d3ed9ac55846b4e84a5f98703fea7208906ca565e5ac5e90c621c816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_9240baf6d3ed9ac55846b4e84a5f98703fea7208906ca565e5ac5e90c621c816->leave($__internal_9240baf6d3ed9ac55846b4e84a5f98703fea7208906ca565e5ac5e90c621c816_prof);

        
        $__internal_083de0e7118f3b47ef5bc2948bd25fb0bdeb3fc572d19fd2180c0f08c890deb2->leave($__internal_083de0e7118f3b47ef5bc2948bd25fb0bdeb3fc572d19fd2180c0f08c890deb2_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_3d338ab1599819da06e99bab8e7a062affd7a484eec5e89a572bc6097b127a93 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d338ab1599819da06e99bab8e7a062affd7a484eec5e89a572bc6097b127a93->enter($__internal_3d338ab1599819da06e99bab8e7a062affd7a484eec5e89a572bc6097b127a93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_495cc5e5263035a2a6e14418f2228bbfa9b1248bf6adb9d2278f15ac20deda30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_495cc5e5263035a2a6e14418f2228bbfa9b1248bf6adb9d2278f15ac20deda30->enter($__internal_495cc5e5263035a2a6e14418f2228bbfa9b1248bf6adb9d2278f15ac20deda30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_495cc5e5263035a2a6e14418f2228bbfa9b1248bf6adb9d2278f15ac20deda30->leave($__internal_495cc5e5263035a2a6e14418f2228bbfa9b1248bf6adb9d2278f15ac20deda30_prof);

        
        $__internal_3d338ab1599819da06e99bab8e7a062affd7a484eec5e89a572bc6097b127a93->leave($__internal_3d338ab1599819da06e99bab8e7a062affd7a484eec5e89a572bc6097b127a93_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "D:\\SoftUni\\Software technologies Exam preparations\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
