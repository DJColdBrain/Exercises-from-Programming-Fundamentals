<?php

/* task/delete.html.twig */
class __TwigTemplate_51e994fb33b2a018c8423b8fdeaaaca1f9f17a26636ed524b479f58726972f2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "task/delete.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4960f14f65e7b23eeb6f614728ab59f7d18ce1419ab1c9f97709abf72dc84b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4960f14f65e7b23eeb6f614728ab59f7d18ce1419ab1c9f97709abf72dc84b9->enter($__internal_b4960f14f65e7b23eeb6f614728ab59f7d18ce1419ab1c9f97709abf72dc84b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/delete.html.twig"));

        $__internal_de68ed76cc225146baf00706c448266ac81446b5d4640f30e1830b05bd65eb74 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de68ed76cc225146baf00706c448266ac81446b5d4640f30e1830b05bd65eb74->enter($__internal_de68ed76cc225146baf00706c448266ac81446b5d4640f30e1830b05bd65eb74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/delete.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b4960f14f65e7b23eeb6f614728ab59f7d18ce1419ab1c9f97709abf72dc84b9->leave($__internal_b4960f14f65e7b23eeb6f614728ab59f7d18ce1419ab1c9f97709abf72dc84b9_prof);

        
        $__internal_de68ed76cc225146baf00706c448266ac81446b5d4640f30e1830b05bd65eb74->leave($__internal_de68ed76cc225146baf00706c448266ac81446b5d4640f30e1830b05bd65eb74_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_78b6613e646f71007c338f400f8310f80dd7acb34affc1f1a8d1f2583474cbc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78b6613e646f71007c338f400f8310f80dd7acb34affc1f1a8d1f2583474cbc7->enter($__internal_78b6613e646f71007c338f400f8310f80dd7acb34affc1f1a8d1f2583474cbc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_42375e9de4feb92618645e7fd56632a39ce90a2a3cc4d2bca720685319b55597 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42375e9de4feb92618645e7fd56632a39ce90a2a3cc4d2bca720685319b55597->enter($__internal_42375e9de4feb92618645e7fd56632a39ce90a2a3cc4d2bca720685319b55597_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div id=\"delete-wrapper\">
        <section class=\"delete\">
            <article>
                <form action=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete", array("id" => $this->getAttribute(($context["task"] ?? $this->getContext($context, "task")), "id", array()))), "html", null, true);
        echo "\" method=\"POST\">
                    <h4>Do you want to delete this item?</h4>
                    <div class=\"box\">
                        <p>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["task"] ?? $this->getContext($context, "task")), "title", array()), "html", null, true);
        echo "</p>
                    </div>
                    <div class=\"box\">
                        <p class=\"description\">";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["task"] ?? $this->getContext($context, "task")), "comments", array()), "html", null, true);
        echo "</p>
                    </div>

                    ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                    <button type=\"submit\">Delete</button>
                    <a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\">Cancel</a>
                </form>
            </article>
        </section>
    </div>
";
        
        $__internal_42375e9de4feb92618645e7fd56632a39ce90a2a3cc4d2bca720685319b55597->leave($__internal_42375e9de4feb92618645e7fd56632a39ce90a2a3cc4d2bca720685319b55597_prof);

        
        $__internal_78b6613e646f71007c338f400f8310f80dd7acb34affc1f1a8d1f2583474cbc7->leave($__internal_78b6613e646f71007c338f400f8310f80dd7acb34affc1f1a8d1f2583474cbc7_prof);

    }

    public function getTemplateName()
    {
        return "task/delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 19,  72 => 16,  66 => 13,  60 => 10,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <div id=\"delete-wrapper\">
        <section class=\"delete\">
            <article>
                <form action=\"{{ path('delete', {'id': task.id}) }}\" method=\"POST\">
                    <h4>Do you want to delete this item?</h4>
                    <div class=\"box\">
                        <p>{{ task.title }}</p>
                    </div>
                    <div class=\"box\">
                        <p class=\"description\">{{ task.comments }}</p>
                    </div>

                    {{ form_row(form._token) }}

                    <button type=\"submit\">Delete</button>
                    <a href=\"{{ path('index') }}\">Cancel</a>
                </form>
            </article>
        </section>
    </div>
{% endblock %}", "task/delete.html.twig", "D:\\SoftUni\\Software technologies Exam preparations\\PHP Skeleton\\app\\Resources\\views\\task\\delete.html.twig");
    }
}
