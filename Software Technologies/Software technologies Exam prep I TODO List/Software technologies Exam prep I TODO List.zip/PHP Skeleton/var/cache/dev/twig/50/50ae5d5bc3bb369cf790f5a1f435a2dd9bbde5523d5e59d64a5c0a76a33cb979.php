<?php

/* task/create.html.twig */
class __TwigTemplate_6e5eea0179c0e14d539c7b4381c84bf8b9ace588f2b99ef32d8733d57eb34b9a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "task/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_673eb16628d81a8bbf06af06e584d4cc0ff504f781ae9661ff900d828c22158f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_673eb16628d81a8bbf06af06e584d4cc0ff504f781ae9661ff900d828c22158f->enter($__internal_673eb16628d81a8bbf06af06e584d4cc0ff504f781ae9661ff900d828c22158f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/create.html.twig"));

        $__internal_f4e26d8eb6a63e1f375e17d055672a5e7794f92e1bf8b577bb07ec700b425e40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4e26d8eb6a63e1f375e17d055672a5e7794f92e1bf8b577bb07ec700b425e40->enter($__internal_f4e26d8eb6a63e1f375e17d055672a5e7794f92e1bf8b577bb07ec700b425e40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "task/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_673eb16628d81a8bbf06af06e584d4cc0ff504f781ae9661ff900d828c22158f->leave($__internal_673eb16628d81a8bbf06af06e584d4cc0ff504f781ae9661ff900d828c22158f_prof);

        
        $__internal_f4e26d8eb6a63e1f375e17d055672a5e7794f92e1bf8b577bb07ec700b425e40->leave($__internal_f4e26d8eb6a63e1f375e17d055672a5e7794f92e1bf8b577bb07ec700b425e40_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_0f5edcfd4cb1df54c95787d438de2b9c451c96f5cf855ccf6da0cab5f181b99d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f5edcfd4cb1df54c95787d438de2b9c451c96f5cf855ccf6da0cab5f181b99d->enter($__internal_0f5edcfd4cb1df54c95787d438de2b9c451c96f5cf855ccf6da0cab5f181b99d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_303d7b6f2120d6713ce38df6bf21a33de35d1f78e2e5630dea828502dcf8ba9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_303d7b6f2120d6713ce38df6bf21a33de35d1f78e2e5630dea828502dcf8ba9b->enter($__internal_303d7b6f2120d6713ce38df6bf21a33de35d1f78e2e5630dea828502dcf8ba9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div id=\"create-wrapper\">
        <section class=\"create\">
            <article>
                <form action=\"";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("create");
        echo "\" method=\"POST\">
                    <div class=\"row\">
                        <label for=\"task\">Task:</label>
                        <input type=\"text\" id=\"task\" name=\"task[title]\">
                    </div>
                    <div class=\"row\">
                        <label for=\"comments\">Comments:</label>
                        <textarea id=\"comments\" name=\"task[comments]\"></textarea>
                    </div>

                    ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                    <button type=\"submit\">Create</button>
                </form>
            </article>
        </section>
    </div>
";
        
        $__internal_303d7b6f2120d6713ce38df6bf21a33de35d1f78e2e5630dea828502dcf8ba9b->leave($__internal_303d7b6f2120d6713ce38df6bf21a33de35d1f78e2e5630dea828502dcf8ba9b_prof);

        
        $__internal_0f5edcfd4cb1df54c95787d438de2b9c451c96f5cf855ccf6da0cab5f181b99d->leave($__internal_0f5edcfd4cb1df54c95787d438de2b9c451c96f5cf855ccf6da0cab5f181b99d_prof);

    }

    public function getTemplateName()
    {
        return "task/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 17,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <div id=\"create-wrapper\">
        <section class=\"create\">
            <article>
                <form action=\"{{ path('create') }}\" method=\"POST\">
                    <div class=\"row\">
                        <label for=\"task\">Task:</label>
                        <input type=\"text\" id=\"task\" name=\"task[title]\">
                    </div>
                    <div class=\"row\">
                        <label for=\"comments\">Comments:</label>
                        <textarea id=\"comments\" name=\"task[comments]\"></textarea>
                    </div>

                    {{ form_row(form._token) }}

                    <button type=\"submit\">Create</button>
                </form>
            </article>
        </section>
    </div>
{% endblock %}", "task/create.html.twig", "D:\\SoftUni\\Software technologies Exam preparations\\PHP Skeleton\\app\\Resources\\views\\task\\create.html.twig");
    }
}
