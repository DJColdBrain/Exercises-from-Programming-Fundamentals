<?php

/* base.html.twig */
class __TwigTemplate_93e2499d03c6402ea1e3906495568257ed0120721f7f5badb0e11600e82927c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f81b2ef0688d81ec453eca016de0a651160bb07080ecc8ad3c3afc41dc81086 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f81b2ef0688d81ec453eca016de0a651160bb07080ecc8ad3c3afc41dc81086->enter($__internal_9f81b2ef0688d81ec453eca016de0a651160bb07080ecc8ad3c3afc41dc81086_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_8b7c8e295c1e433be1ad98cad16e8e610a3bceb3979a5b0fc65a41e892da906a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b7c8e295c1e433be1ad98cad16e8e610a3bceb3979a5b0fc65a41e892da906a->enter($__internal_8b7c8e295c1e433be1ad98cad16e8e610a3bceb3979a5b0fc65a41e892da906a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 20
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">
";
        // line 21
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "</body>
</html>
";
        
        $__internal_9f81b2ef0688d81ec453eca016de0a651160bb07080ecc8ad3c3afc41dc81086->leave($__internal_9f81b2ef0688d81ec453eca016de0a651160bb07080ecc8ad3c3afc41dc81086_prof);

        
        $__internal_8b7c8e295c1e433be1ad98cad16e8e610a3bceb3979a5b0fc65a41e892da906a->leave($__internal_8b7c8e295c1e433be1ad98cad16e8e610a3bceb3979a5b0fc65a41e892da906a_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_8874be753bfc0c551af29c8a9ecdd356bd3e8814b3aee66d71678d82306f2782 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8874be753bfc0c551af29c8a9ecdd356bd3e8814b3aee66d71678d82306f2782->enter($__internal_8874be753bfc0c551af29c8a9ecdd356bd3e8814b3aee66d71678d82306f2782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_c94ca33d5d81313cdf73d7a05a7745dac008f871edec939e3ced53916b7a2b7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c94ca33d5d81313cdf73d7a05a7745dac008f871edec939e3ced53916b7a2b7a->enter($__internal_c94ca33d5d81313cdf73d7a05a7745dac008f871edec939e3ced53916b7a2b7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "IMDB";
        
        $__internal_c94ca33d5d81313cdf73d7a05a7745dac008f871edec939e3ced53916b7a2b7a->leave($__internal_c94ca33d5d81313cdf73d7a05a7745dac008f871edec939e3ced53916b7a2b7a_prof);

        
        $__internal_8874be753bfc0c551af29c8a9ecdd356bd3e8814b3aee66d71678d82306f2782->leave($__internal_8874be753bfc0c551af29c8a9ecdd356bd3e8814b3aee66d71678d82306f2782_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d7d099485b642544b69636c03cf110739b43b9b38be72355d4768857aef80be5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7d099485b642544b69636c03cf110739b43b9b38be72355d4768857aef80be5->enter($__internal_d7d099485b642544b69636c03cf110739b43b9b38be72355d4768857aef80be5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_20b2fb8be037a3caf429a4dad13371e3e83da02e65ff446d1dc6b18f24a5e9ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20b2fb8be037a3caf429a4dad13371e3e83da02e65ff446d1dc6b18f24a5e9ad->enter($__internal_20b2fb8be037a3caf429a4dad13371e3e83da02e65ff446d1dc6b18f24a5e9ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        ";
        // line 14
        echo "        ";
        // line 15
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_20b2fb8be037a3caf429a4dad13371e3e83da02e65ff446d1dc6b18f24a5e9ad->leave($__internal_20b2fb8be037a3caf429a4dad13371e3e83da02e65ff446d1dc6b18f24a5e9ad_prof);

        
        $__internal_d7d099485b642544b69636c03cf110739b43b9b38be72355d4768857aef80be5->leave($__internal_d7d099485b642544b69636c03cf110739b43b9b38be72355d4768857aef80be5_prof);

    }

    // line 20
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_1a4c241a5fd63606f95caacb0626a69c96341484791b7291159e2edb693575aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a4c241a5fd63606f95caacb0626a69c96341484791b7291159e2edb693575aa->enter($__internal_1a4c241a5fd63606f95caacb0626a69c96341484791b7291159e2edb693575aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_c2bb5b2bbcff3a074156e5ac1e9b4b51407c5ac218046644c7a57267872aea67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2bb5b2bbcff3a074156e5ac1e9b4b51407c5ac218046644c7a57267872aea67->enter($__internal_c2bb5b2bbcff3a074156e5ac1e9b4b51407c5ac218046644c7a57267872aea67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_c2bb5b2bbcff3a074156e5ac1e9b4b51407c5ac218046644c7a57267872aea67->leave($__internal_c2bb5b2bbcff3a074156e5ac1e9b4b51407c5ac218046644c7a57267872aea67_prof);

        
        $__internal_1a4c241a5fd63606f95caacb0626a69c96341484791b7291159e2edb693575aa->leave($__internal_1a4c241a5fd63606f95caacb0626a69c96341484791b7291159e2edb693575aa_prof);

    }

    // line 21
    public function block_body($context, array $blocks = array())
    {
        $__internal_c90058c453af5999a873779855d373a856b7ba2cd4f48efb2d831b1d8d99980c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c90058c453af5999a873779855d373a856b7ba2cd4f48efb2d831b1d8d99980c->enter($__internal_c90058c453af5999a873779855d373a856b7ba2cd4f48efb2d831b1d8d99980c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5a3f2e3c59f6a7480678f5e399cf5e1950e7accdbef7d856026ec7766f2cd2da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a3f2e3c59f6a7480678f5e399cf5e1950e7accdbef7d856026ec7766f2cd2da->enter($__internal_5a3f2e3c59f6a7480678f5e399cf5e1950e7accdbef7d856026ec7766f2cd2da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 22
        echo "    ";
        $this->displayBlock('main', $context, $blocks);
        
        $__internal_5a3f2e3c59f6a7480678f5e399cf5e1950e7accdbef7d856026ec7766f2cd2da->leave($__internal_5a3f2e3c59f6a7480678f5e399cf5e1950e7accdbef7d856026ec7766f2cd2da_prof);

        
        $__internal_c90058c453af5999a873779855d373a856b7ba2cd4f48efb2d831b1d8d99980c->leave($__internal_c90058c453af5999a873779855d373a856b7ba2cd4f48efb2d831b1d8d99980c_prof);

    }

    public function block_main($context, array $blocks = array())
    {
        $__internal_df4cae3cc9cc7977c1d075a7186c44758776c2324ca04ecd9f0938312a2e760e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df4cae3cc9cc7977c1d075a7186c44758776c2324ca04ecd9f0938312a2e760e->enter($__internal_df4cae3cc9cc7977c1d075a7186c44758776c2324ca04ecd9f0938312a2e760e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_8def39d9344cc9e443e2e7d17305ed1961aac87a18b82010c16b15f96b70967b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8def39d9344cc9e443e2e7d17305ed1961aac87a18b82010c16b15f96b70967b->enter($__internal_8def39d9344cc9e443e2e7d17305ed1961aac87a18b82010c16b15f96b70967b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_8def39d9344cc9e443e2e7d17305ed1961aac87a18b82010c16b15f96b70967b->leave($__internal_8def39d9344cc9e443e2e7d17305ed1961aac87a18b82010c16b15f96b70967b_prof);

        
        $__internal_df4cae3cc9cc7977c1d075a7186c44758776c2324ca04ecd9f0938312a2e760e->leave($__internal_df4cae3cc9cc7977c1d075a7186c44758776c2324ca04ecd9f0938312a2e760e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 22,  129 => 21,  112 => 20,  99 => 15,  97 => 14,  95 => 13,  86 => 12,  68 => 11,  56 => 24,  54 => 21,  50 => 20,  43 => 17,  41 => 12,  37 => 11,  30 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}IMDB{% endblock %}</title>
    {% block stylesheets %}
        {#<link rel=\"stylesheet\" href=\"{{ asset('css/reset-style.css') }}\">;#}
        {#<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">#}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">
{% block body %}
    {% block main %}{% endblock %}
{% endblock %}
</body>
</html>
", "base.html.twig", "D:\\SoftUni\\Software technologies Exam prep III IMDB\\PHP Skeleton\\app\\Resources\\views\\base.html.twig");
    }
}
