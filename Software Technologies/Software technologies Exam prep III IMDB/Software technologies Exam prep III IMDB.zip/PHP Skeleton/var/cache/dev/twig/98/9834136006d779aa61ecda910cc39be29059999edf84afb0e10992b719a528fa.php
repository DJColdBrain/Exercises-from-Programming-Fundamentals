<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_09886c37796d81d574b2448cf2a22ea32da8dad546b69f22c376ce19a869ce97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f2c7f16c2f97acb0fb6a76f939532fc9a1c55506c35635e586e0db85d6a24fc3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f2c7f16c2f97acb0fb6a76f939532fc9a1c55506c35635e586e0db85d6a24fc3->enter($__internal_f2c7f16c2f97acb0fb6a76f939532fc9a1c55506c35635e586e0db85d6a24fc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_f4b517155ff735b64d047f64f95b8d5b5ddbb6603f75c2edbf866b9a288a6bd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4b517155ff735b64d047f64f95b8d5b5ddbb6603f75c2edbf866b9a288a6bd6->enter($__internal_f4b517155ff735b64d047f64f95b8d5b5ddbb6603f75c2edbf866b9a288a6bd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f2c7f16c2f97acb0fb6a76f939532fc9a1c55506c35635e586e0db85d6a24fc3->leave($__internal_f2c7f16c2f97acb0fb6a76f939532fc9a1c55506c35635e586e0db85d6a24fc3_prof);

        
        $__internal_f4b517155ff735b64d047f64f95b8d5b5ddbb6603f75c2edbf866b9a288a6bd6->leave($__internal_f4b517155ff735b64d047f64f95b8d5b5ddbb6603f75c2edbf866b9a288a6bd6_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_3c012f18d34528aaf420f68d0bc03d6c34b184531ed35ceac8b4e43393a88448 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c012f18d34528aaf420f68d0bc03d6c34b184531ed35ceac8b4e43393a88448->enter($__internal_3c012f18d34528aaf420f68d0bc03d6c34b184531ed35ceac8b4e43393a88448_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_284b1a8d20285b16c71a2038d9d56511adb7faa645dfa8fc49193a94d3697889 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_284b1a8d20285b16c71a2038d9d56511adb7faa645dfa8fc49193a94d3697889->enter($__internal_284b1a8d20285b16c71a2038d9d56511adb7faa645dfa8fc49193a94d3697889_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_284b1a8d20285b16c71a2038d9d56511adb7faa645dfa8fc49193a94d3697889->leave($__internal_284b1a8d20285b16c71a2038d9d56511adb7faa645dfa8fc49193a94d3697889_prof);

        
        $__internal_3c012f18d34528aaf420f68d0bc03d6c34b184531ed35ceac8b4e43393a88448->leave($__internal_3c012f18d34528aaf420f68d0bc03d6c34b184531ed35ceac8b4e43393a88448_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a1b08dfc58480992cf7800b945662a43e188af89838c0314cf92bb84b40c3174 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1b08dfc58480992cf7800b945662a43e188af89838c0314cf92bb84b40c3174->enter($__internal_a1b08dfc58480992cf7800b945662a43e188af89838c0314cf92bb84b40c3174_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_a4f97fd5080ed9dad0ccadbd035bb3ec2877562b6e4f55ea2b4be116b3f6b499 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4f97fd5080ed9dad0ccadbd035bb3ec2877562b6e4f55ea2b4be116b3f6b499->enter($__internal_a4f97fd5080ed9dad0ccadbd035bb3ec2877562b6e4f55ea2b4be116b3f6b499_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a4f97fd5080ed9dad0ccadbd035bb3ec2877562b6e4f55ea2b4be116b3f6b499->leave($__internal_a4f97fd5080ed9dad0ccadbd035bb3ec2877562b6e4f55ea2b4be116b3f6b499_prof);

        
        $__internal_a1b08dfc58480992cf7800b945662a43e188af89838c0314cf92bb84b40c3174->leave($__internal_a1b08dfc58480992cf7800b945662a43e188af89838c0314cf92bb84b40c3174_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_bd281f6de6a51a8e6aba9d6dfd2a7ec0b8f4f64db70c4e81f518f4429402018e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd281f6de6a51a8e6aba9d6dfd2a7ec0b8f4f64db70c4e81f518f4429402018e->enter($__internal_bd281f6de6a51a8e6aba9d6dfd2a7ec0b8f4f64db70c4e81f518f4429402018e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_44ea2af226273c869618e5f2beba03b6bbf143c148b45e93736b2cd9543977f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44ea2af226273c869618e5f2beba03b6bbf143c148b45e93736b2cd9543977f4->enter($__internal_44ea2af226273c869618e5f2beba03b6bbf143c148b45e93736b2cd9543977f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_44ea2af226273c869618e5f2beba03b6bbf143c148b45e93736b2cd9543977f4->leave($__internal_44ea2af226273c869618e5f2beba03b6bbf143c148b45e93736b2cd9543977f4_prof);

        
        $__internal_bd281f6de6a51a8e6aba9d6dfd2a7ec0b8f4f64db70c4e81f518f4429402018e->leave($__internal_bd281f6de6a51a8e6aba9d6dfd2a7ec0b8f4f64db70c4e81f518f4429402018e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "D:\\SoftUni\\Software technologies Exam prep III IMDB\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
