<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_38a6c797aab9659831372987100a40392803c422a7b2171a144e8b5467094f9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ae530e1e0e92ccce51ba7e2d3f178db5e29ddbb41f56e31311a34fd374f3832 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ae530e1e0e92ccce51ba7e2d3f178db5e29ddbb41f56e31311a34fd374f3832->enter($__internal_9ae530e1e0e92ccce51ba7e2d3f178db5e29ddbb41f56e31311a34fd374f3832_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_c1f77b95a685a9690b029b9fdb11b945d5d765ae538b444cfcc9588dce862a36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1f77b95a685a9690b029b9fdb11b945d5d765ae538b444cfcc9588dce862a36->enter($__internal_c1f77b95a685a9690b029b9fdb11b945d5d765ae538b444cfcc9588dce862a36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_9ae530e1e0e92ccce51ba7e2d3f178db5e29ddbb41f56e31311a34fd374f3832->leave($__internal_9ae530e1e0e92ccce51ba7e2d3f178db5e29ddbb41f56e31311a34fd374f3832_prof);

        
        $__internal_c1f77b95a685a9690b029b9fdb11b945d5d765ae538b444cfcc9588dce862a36->leave($__internal_c1f77b95a685a9690b029b9fdb11b945d5d765ae538b444cfcc9588dce862a36_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "D:\\SoftUni\\Software technologies Exam prep III IMDB\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\chevron-right.svg");
    }
}
