<?php

/* film/edit.html.twig */
class __TwigTemplate_f95d725639f60feb56a914417ea3d7b3f300f22b85dcbdd4b83a5a792c89f99b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "film/edit.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c83293599f4f353b19dfd4a34f7b3408f1b8d3bf3b1945a5113ccbcf775169d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c83293599f4f353b19dfd4a34f7b3408f1b8d3bf3b1945a5113ccbcf775169d5->enter($__internal_c83293599f4f353b19dfd4a34f7b3408f1b8d3bf3b1945a5113ccbcf775169d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/edit.html.twig"));

        $__internal_590f19033c901b30877ed9606232d3fd7cfec0b78726ac406642bc44ff60e8f7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_590f19033c901b30877ed9606232d3fd7cfec0b78726ac406642bc44ff60e8f7->enter($__internal_590f19033c901b30877ed9606232d3fd7cfec0b78726ac406642bc44ff60e8f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c83293599f4f353b19dfd4a34f7b3408f1b8d3bf3b1945a5113ccbcf775169d5->leave($__internal_c83293599f4f353b19dfd4a34f7b3408f1b8d3bf3b1945a5113ccbcf775169d5_prof);

        
        $__internal_590f19033c901b30877ed9606232d3fd7cfec0b78726ac406642bc44ff60e8f7->leave($__internal_590f19033c901b30877ed9606232d3fd7cfec0b78726ac406642bc44ff60e8f7_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_92a10487cb039b238bc93cc72da78abe61f66dbbe5c7b558de1272d14282df5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92a10487cb039b238bc93cc72da78abe61f66dbbe5c7b558de1272d14282df5c->enter($__internal_92a10487cb039b238bc93cc72da78abe61f66dbbe5c7b558de1272d14282df5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_38b063239fdd4c695912440e58192d672dd39fdbe34131bf3c116749d63eba26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38b063239fdd4c695912440e58192d672dd39fdbe34131bf3c116749d63eba26->enter($__internal_38b063239fdd4c695912440e58192d672dd39fdbe34131bf3c116749d63eba26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <h1>Edit Film</h1>
    <section>
        <form method=\"POST\">
            <div>
                <label for=\"name\">Name</label>
                <input type=\"text\" id=\"name\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "name", array()), "html", null, true);
        echo "\" name=\"film[name]\" />
                <label for=\"genre\">Genre</label>
                <input type=\"text\" id=\"genre\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "genre", array()), "html", null, true);
        echo "\" name=\"film[genre]\" />
                <label for=\"director\">Director</label>
                <input type=\"text\" id=\"director\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "director", array()), "html", null, true);
        echo "\" name=\"film[director]\" />
                <label for=\"year\">Year</label>
                <input type=\"text\" id=\"year\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["film"] ?? $this->getContext($context, "film")), "year", array()), "html", null, true);
        echo "\" name=\"film[year]\" />

                ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                <button type=\"submit\" class=\"accept\">Edit</button>
                <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
            </div>
        </form>
    </section>
";
        
        $__internal_38b063239fdd4c695912440e58192d672dd39fdbe34131bf3c116749d63eba26->leave($__internal_38b063239fdd4c695912440e58192d672dd39fdbe34131bf3c116749d63eba26_prof);

        
        $__internal_92a10487cb039b238bc93cc72da78abe61f66dbbe5c7b558de1272d14282df5c->leave($__internal_92a10487cb039b238bc93cc72da78abe61f66dbbe5c7b558de1272d14282df5c_prof);

    }

    public function getTemplateName()
    {
        return "film/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 17,  71 => 15,  66 => 13,  61 => 11,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <h1>Edit Film</h1>
    <section>
        <form method=\"POST\">
            <div>
                <label for=\"name\">Name</label>
                <input type=\"text\" id=\"name\" value=\"{{ film.name }}\" name=\"film[name]\" />
                <label for=\"genre\">Genre</label>
                <input type=\"text\" id=\"genre\" value=\"{{ film.genre }}\" name=\"film[genre]\" />
                <label for=\"director\">Director</label>
                <input type=\"text\" id=\"director\" value=\"{{ film.director }}\" name=\"film[director]\" />
                <label for=\"year\">Year</label>
                <input type=\"text\" id=\"year\" value=\"{{ film.year }}\" name=\"film[year]\" />

                {{ form_row(form._token) }}

                <button type=\"submit\" class=\"accept\">Edit</button>
                <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
            </div>
        </form>
    </section>
{% endblock %}", "film/edit.html.twig", "D:\\SoftUni\\Software technologies Exam prep III IMDB\\PHP Skeleton\\app\\Resources\\views\\film\\edit.html.twig");
    }
}
