<?php

/* film/create.html.twig */
class __TwigTemplate_009a3431b9c1c7980acb206521572a7ee7f2371c50f7fdf88da4a9578275933e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "film/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_30a3ac23952895a3d909fb79a402a0021fe6958de8a25dc60a74065fd5f9ce77 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30a3ac23952895a3d909fb79a402a0021fe6958de8a25dc60a74065fd5f9ce77->enter($__internal_30a3ac23952895a3d909fb79a402a0021fe6958de8a25dc60a74065fd5f9ce77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/create.html.twig"));

        $__internal_4f185e09d28a4dcfcbed1db3d976198a41ec89ce939fb5c20e5275eed7cd79fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f185e09d28a4dcfcbed1db3d976198a41ec89ce939fb5c20e5275eed7cd79fa->enter($__internal_4f185e09d28a4dcfcbed1db3d976198a41ec89ce939fb5c20e5275eed7cd79fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "film/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_30a3ac23952895a3d909fb79a402a0021fe6958de8a25dc60a74065fd5f9ce77->leave($__internal_30a3ac23952895a3d909fb79a402a0021fe6958de8a25dc60a74065fd5f9ce77_prof);

        
        $__internal_4f185e09d28a4dcfcbed1db3d976198a41ec89ce939fb5c20e5275eed7cd79fa->leave($__internal_4f185e09d28a4dcfcbed1db3d976198a41ec89ce939fb5c20e5275eed7cd79fa_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_ab6f32c15bee85380674b71dc09ef4d9b3d3d576036b383c011656cbfb65c10d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ab6f32c15bee85380674b71dc09ef4d9b3d3d576036b383c011656cbfb65c10d->enter($__internal_ab6f32c15bee85380674b71dc09ef4d9b3d3d576036b383c011656cbfb65c10d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_f91b5500895de03814f051cc20ebf6233bcc2f1afb07f34716ad2185e48b63b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f91b5500895de03814f051cc20ebf6233bcc2f1afb07f34716ad2185e48b63b6->enter($__internal_f91b5500895de03814f051cc20ebf6233bcc2f1afb07f34716ad2185e48b63b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>Create Film</h1>
<section>
    <form method=\"POST\">
        <div>
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"film[name]\" />
            <label for=\"genre\">Genre</label>
            <input type=\"text\" id=\"genre\" name=\"film[genre]\" />
            <label for=\"director\">Director</label>
            <input type=\"text\" id=\"director\" name=\"film[director]\" />
            <label for=\"year\">Year</label>
            <input type=\"text\" id=\"year\" name=\"film[year]\" />

            ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
        </div>
    </form>
</section>
";
        
        $__internal_f91b5500895de03814f051cc20ebf6233bcc2f1afb07f34716ad2185e48b63b6->leave($__internal_f91b5500895de03814f051cc20ebf6233bcc2f1afb07f34716ad2185e48b63b6_prof);

        
        $__internal_ab6f32c15bee85380674b71dc09ef4d9b3d3d576036b383c011656cbfb65c10d->leave($__internal_ab6f32c15bee85380674b71dc09ef4d9b3d3d576036b383c011656cbfb65c10d_prof);

    }

    public function getTemplateName()
    {
        return "film/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 17,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>Create Film</h1>
<section>
    <form method=\"POST\">
        <div>
            <label for=\"name\">Name</label>
            <input type=\"text\" id=\"name\" name=\"film[name]\" />
            <label for=\"genre\">Genre</label>
            <input type=\"text\" id=\"genre\" name=\"film[genre]\" />
            <label for=\"director\">Director</label>
            <input type=\"text\" id=\"director\" name=\"film[director]\" />
            <label for=\"year\">Year</label>
            <input type=\"text\" id=\"year\" name=\"film[year]\" />

            {{ form_row(form._token) }}

            <button type=\"submit\" class=\"accept\">Create</button>
            <button type=\"button\" onclick=\"location.href='/'\" class=\"cancel\">Cancel</button>
        </div>
    </form>
</section>
{% endblock %}", "film/create.html.twig", "D:\\SoftUni\\Software technologies Exam prep III IMDB\\PHP Skeleton\\app\\Resources\\views\\film\\create.html.twig");
    }
}
